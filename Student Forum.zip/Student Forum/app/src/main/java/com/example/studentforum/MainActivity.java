package com.example.studentforum;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner mySpinner = (Spinner) findViewById(R.id.spinner1);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        Button button = (Button) findViewById(R.id.help_view);
        Button button2 = (Button) findViewById(R.id.aboutus_view);

        final MediaPlayer np= MediaPlayer.create(this,R.raw.buttonsound);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//work the button should work is set by ClickListener
                np.start();
                Intent intent = new Intent(MainActivity.this, AboutusActivity.class);//(this acitvity,next activity)
                startActivity(intent);//intent to go to another activity
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//work the button should work is set by ClickListener
                np.start();
                Intent intent = new Intent(MainActivity.this, HelpActivity.class);//(this acitvity,next activity)
                startActivity(intent);//intent to go to another activity
            }
        });




        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 1) {
                    startActivity(new Intent(MainActivity.this, ClubActivity.class));
                } else if (i == 2) {
                    startActivity(new Intent(MainActivity.this, AcademicsActivity.class));
                }else if (i == 3) {
                    startActivity(new Intent(MainActivity.this, EventsActivity.class));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    @Override
    public void onBackPressed()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Confirm");
        builder.setMessage("Are you sure?");

        builder.setPositiveButton("YES", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                // Do nothing but close the dialog
                finish();
                //dialog.dismiss();
            }
        });

        builder.setNegativeButton("NO", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {

                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }
}
